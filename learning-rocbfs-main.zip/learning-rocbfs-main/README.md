# RO-CBF

## Dependencies
* Carla 0.9.11 (we used overnight build version, but it should work for the full installation).
