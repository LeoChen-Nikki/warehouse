This folders contains the necessary codes to interface with Carla.

* The four .py files are used to simulate an autonomous vehicle controlled with trained cbf at different conditions.
* map/ contains the recorded map to act as waypoints in our simulation.
* include/ includes files that are modifications of the PID controller provided by Carla, and they need to be put in the "carla/agents/navigation/" directory in your Carla installation.
